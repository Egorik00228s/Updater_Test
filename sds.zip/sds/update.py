import os
import sys
import urllib.request
import zipfile
import shutil

# Путь к серверу, где размещена последняя версия приложения
UPDATE_URL = 'https://github.com/Egorik00228s/Updater_Test/raw/refs/heads/main/sds.zip'
# Путь к версии приложения на сервере
VERSION_URL = 'https://github.com/Egorik00228s/Updater_Test/raw/refs/heads/main/version.txt'

def get_current_version():
    return "1.0.0"

def check_for_updates():
    # Получаем последнюю версию с сервера
    with urllib.request.urlopen(VERSION_URL) as response:
        latest_version = response.read().decode().strip()
    current_version = get_current_version()

    if current_version != latest_version:
        print(f"Доступна новая версия: {latest_version}")
        return True
    else:
        print("Вы используете последнюю версию.")
        return False

def download_update():
    update_file = 'update.zip'
    urllib.request.urlretrieve(UPDATE_URL, update_file)
    return update_file

def install_update(file_path):
    with zipfile.ZipFile(file_path, 'r') as zip_ref:
        zip_ref.extractall('update')

    for item in os.listdir('update'):
        s = os.path.join('update', item)
        d = os.path.join('.', item)
        if os.path.isdir(s):
            shutil.copytree(s, d, dirs_exist_ok=True)
        else:
            shutil.copy2(s, d)
    shutil.rmtree('update')
    os.remove(file_path)
    print("Успешно обновлено!")

def main():
    if check_for_updates():
        update_file = download_update()
        install_update(update_file)
        print("Приложение будет перезапущено.")
        os.execv(sys.executable, ['python'] + sys.argv)

if __name__ == '__main__':
    main()